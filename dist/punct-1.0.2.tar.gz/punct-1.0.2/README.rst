punct
=====

Punct is a simplistic todo-list for the shell, made in python.

Installation
------------

Not buildable through pip yet. This is a hacky workaround ( unix ):
*******************************************************************

1) run in terminal::

    pip3 install --upgrade punct

2) Add this to your shell's .rc file::

    alias punct='cd ~/git/punct/src/ && python punct.py'