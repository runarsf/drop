# -*- coding: utf-8 -*-


"""punct.__main__: executed when punct directory is called as script."""


from .punct import main
main()